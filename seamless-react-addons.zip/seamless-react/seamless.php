<?php

/**
 * Plugin Name:       Seamless React
 * Plugin URI:        https://seamlessams.com
 * Description:       React-powered addon for events, memberships, courses and user dashboard with SSO. Uses Shadow DOM for style isolation.
 * Version:           2.0.0
 * Author:            Actualize Studio
 * Author URI:        https://vardaam.com
 * License:           GPL2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       seamless-react
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Tested up to:      6.5
 * Requires PHP:      8.0
 */

// ─── Security: Abort direct access ───────────────────────────────────────────
if ( ! defined( 'WPINC' ) ) {
	die;
}

// ─── Constants ───────────────────────────────────────────────────────────────
define( 'SEAMLESS_REACT_VERSION',   '2.0.0' );
define( 'SEAMLESS_REACT_FILE',      __FILE__ );
define( 'SEAMLESS_REACT_DIR',       plugin_dir_path( __FILE__ ) );
define( 'SEAMLESS_REACT_URL',       plugin_dir_url( __FILE__ ) );
define( 'SEAMLESS_REACT_BASENAME',  plugin_basename( __FILE__ ) );
define( 'SEAMLESS_REACT_SRC_DIR',   SEAMLESS_REACT_DIR . 'src/' );
define( 'SEAMLESS_REACT_BUILD_DIR', SEAMLESS_REACT_DIR . 'react-build/dist/' );
define( 'SEAMLESS_REACT_BUILD_URL', SEAMLESS_REACT_URL . 'react-build/dist/' );

// ─── Compatibility checks ─────────────────────────────────────────────────────
function seamless_react_check_compatibility(): bool {
	$ok = true;

	if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
		add_action( 'admin_notices', 'seamless_react_php_notice' );
		$ok = false;
	}

	global $wp_version;
	if ( version_compare( $wp_version, '6.0', '<' ) ) {
		add_action( 'admin_notices', 'seamless_react_wp_notice' );
		$ok = false;
	}

	return $ok;
}

function seamless_react_php_notice(): void {
	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		sprintf(
			esc_html__( 'Seamless React requires PHP 8.0 or higher. Current: %s', 'seamless-react' ),
			esc_html( PHP_VERSION )
		)
	);
}

function seamless_react_wp_notice(): void {
	global $wp_version;
	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		sprintf(
			esc_html__( 'Seamless React requires WordPress 6.0 or higher. Current: %s', 'seamless-react' ),
			esc_html( $wp_version )
		)
	);
}

if ( ! seamless_react_check_compatibility() ) {
	return;
}

// ─── Autoloader ──────────────────────────────────────────────────────────────
require_once SEAMLESS_REACT_SRC_DIR . 'Autoloader.php';

// ─── Bootstrap ───────────────────────────────────────────────────────────────
function seamless_react_init(): void {
	load_plugin_textdomain( 'seamless-react', false, dirname( SEAMLESS_REACT_BASENAME ) . '/languages' );
	\SeamlessReact\Autoloader::get_instance();
}
add_action( 'plugins_loaded', 'seamless_react_init' );

// ─── Activation / Deactivation ───────────────────────────────────────────────
function seamless_react_activate(): void {
	require_once SEAMLESS_REACT_SRC_DIR . 'Autoloader.php';

	if ( ! get_option( 'seamless_react_ams_content_endpoint' ) ) {
		add_option( 'seamless_react_ams_content_endpoint', 'ams-content' );
	}
	if ( ! get_option( 'seamless_react_event_list_endpoint' ) ) {
		add_option( 'seamless_react_event_list_endpoint', 'events' );
	}
	if ( ! get_option( 'seamless_react_single_event_endpoint' ) ) {
		add_option( 'seamless_react_single_event_endpoint', 'event' );
	}

	$endpoints = new \SeamlessReact\Endpoints\Endpoints();
	$endpoints->register_rewrite_rules();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'seamless_react_activate' );

function seamless_react_deactivate(): void {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'seamless_react_deactivate' );
