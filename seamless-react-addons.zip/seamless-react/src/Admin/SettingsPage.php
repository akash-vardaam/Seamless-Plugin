<?php

namespace SeamlessReact\Admin;

use SeamlessReact\Auth\SeamlessAuth as Auth;
use SeamlessReact\Auth\SeamlessSSO  as SSO;

/**
 * Admin settings page rendered via the WordPress admin menu.
 * Uses only WordPress nonces for AJAX actions – no custom REST endpoints exposed.
 */
class SettingsPage {

	private Auth $auth;
	private SSO  $sso;

	public function __construct() {
		$this->auth = new Auth();
		$this->sso  = new SSO();

		add_action( 'admin_menu',              [ $this, 'add_menu' ] );
		add_action( 'admin_init',              [ $this, 'register_settings' ] );
		add_action( 'admin_enqueue_scripts',   [ $this, 'enqueue_admin_assets' ] );
		add_action( 'wp_ajax_seamless_react_save_and_connect', [ $this, 'handle_save_and_connect' ] );
		add_action( 'wp_ajax_seamless_react_disconnect',       [ $this, 'handle_disconnect' ] );
		add_filter( 'wp_redirect',             [ $this, 'preserve_tab_on_redirect' ], 10, 2 );

		// Flush rewrite rules when endpoint options change
		foreach ( [ 'seamless_react_event_list_endpoint', 'seamless_react_single_event_endpoint', 'seamless_react_ams_content_endpoint' ] as $opt ) {
			add_action( "update_option_{$opt}", [ $this, 'schedule_flush' ] );
		}
		add_action( 'admin_init', [ $this, 'maybe_flush_rewrite_rules' ] );
	}

	// ─── Menu ─────────────────────────────────────────────────────────────────

	public function add_menu(): void {
		add_menu_page(
			__( 'Seamless React', 'seamless-react' ),
			__( 'Seamless React', 'seamless-react' ),
			'manage_options',
			'seamless-react',
			[ $this, 'render_page' ],
			'dashicons-admin-generic',
			61
		);
	}

	// ─── Settings registration ────────────────────────────────────────────────

	public function register_settings(): void {
		// Auth
		register_setting( 'seamless_react_auth', 'seamless_react_client_domain',   [ 'sanitize_callback' => 'sanitize_text_field' ] );
		register_setting( 'seamless_react_auth', 'seamless_react_redirect_url',    [ 'sanitize_callback' => 'sanitize_text_field' ] );

		// Endpoints
		register_setting( 'seamless_react_endpoints', 'seamless_react_event_list_endpoint',   [ 'sanitize_callback' => 'sanitize_title_with_dashes' ] );
		register_setting( 'seamless_react_endpoints', 'seamless_react_single_event_endpoint', [ 'sanitize_callback' => 'sanitize_title_with_dashes' ] );
		register_setting( 'seamless_react_endpoints', 'seamless_react_ams_content_endpoint',  [ 'sanitize_callback' => 'sanitize_title_with_dashes' ] );

		// Advanced
		register_setting( 'seamless_react_advanced', 'seamless_react_color_scheme',    [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'theme' ] );
		register_setting( 'seamless_react_advanced', 'seamless_react_primary_color',   [ 'sanitize_callback' => 'sanitize_hex_color',  'default' => '#26337a' ] );
		register_setting( 'seamless_react_advanced', 'seamless_react_secondary_color', [ 'sanitize_callback' => 'sanitize_hex_color',  'default' => '#06b6d4' ] );
		register_setting( 'seamless_react_advanced', 'seamless_react_list_view_layout', [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'option_1' ] );

		// Content restriction
		register_setting( 'seamless_react_restriction', 'seamless_react_protected_post_types', [ 'sanitize_callback' => 'sanitize_text_field' ] );
		register_setting( 'seamless_react_restriction', 'seamless_react_restriction_message',  [ 'sanitize_callback' => 'wp_kses_post' ] );
		register_setting( 'seamless_react_restriction', 'seamless_react_membership_purchase_url', [ 'sanitize_callback' => 'esc_url_raw' ] );

		// SSO
		register_setting( 'seamless_react_sso', 'seamless_react_sso_client_id', [ 'sanitize_callback' => 'sanitize_text_field' ] );
		register_setting( 'seamless_react_sso', 'seamless_react_sso_enabled',   [ 'sanitize_callback' => 'absint', 'default' => 0 ] );

		// Store the redirect URI
		update_option( 'seamless_react_redirect_uri', rest_url( SSO::REST_NAMESPACE . '/callback' ) );
	}

	// ─── Admin assets ─────────────────────────────────────────────────────────

	public function enqueue_admin_assets( string $hook ): void {
		if ( ! str_contains( $hook, 'seamless-react' ) ) {
			return;
		}

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		wp_enqueue_script(
			'seamless-react-admin',
			SEAMLESS_REACT_URL . 'src/Admin/assets/js/admin.js',
			[ 'jquery', 'wp-color-picker' ],
			SEAMLESS_REACT_VERSION,
			true
		);

		wp_localize_script( 'seamless-react-admin', 'seamlessReactAdmin', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'seamless_react_admin' ),
			'saveConnectNonce'  => wp_create_nonce( 'seamless_react_save_and_connect' ),
			'disconnectNonce'   => wp_create_nonce( 'seamless_react_disconnect' ),
		] );

		wp_enqueue_style(
			'seamless-react-admin-css',
			SEAMLESS_REACT_URL . 'src/Admin/assets/css/admin.css',
			[],
			SEAMLESS_REACT_VERSION
		);
	}

	// ─── AJAX: save & connect ─────────────────────────────────────────────────

	public function handle_save_and_connect(): void {
		check_ajax_referer( 'seamless_react_save_and_connect', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions.', 403 );
		}

		$domain = sanitize_text_field( $_POST['client_domain'] ?? '' );
		if ( empty( $domain ) ) {
			wp_send_json_error( 'Domain is required.' );
		}

		update_option( 'seamless_react_client_domain', $domain );
		delete_option( 'seamless_react_manual_disconnect' );

		// Re-create auth instance with new domain
		$auth   = new Auth();
		$token  = $auth->fetch_token();

		if ( $token ) {
			wp_send_json_success( [
				'message' => sprintf( __( 'Connected to %s', 'seamless-react' ), esc_html( $domain ) ),
			] );
		} else {
			$error = get_option( 'seamless_react_last_auth_error', 'Connection failed.' );
			wp_send_json_error( $error );
		}
	}

	public function handle_disconnect(): void {
		check_ajax_referer( 'seamless_react_disconnect', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions.', 403 );
		}
		$this->auth->disconnect();
		wp_send_json_success( 'Disconnected.' );
	}

	// ─── Rewrite flush helpers ────────────────────────────────────────────────

	public function schedule_flush(): void {
		update_option( 'seamless_react_flush_rewrite_rules', 1 );
	}

	public function maybe_flush_rewrite_rules(): void {
		if ( get_option( 'seamless_react_flush_rewrite_rules' ) ) {
			delete_option( 'seamless_react_flush_rewrite_rules' );
			flush_rewrite_rules();
		}
	}

	public function preserve_tab_on_redirect( string $location, int $status ): string {
		if ( $status === 302 && str_contains( $location, 'options.php' ) ) {
			$tab = sanitize_text_field( $_POST['_seamless_react_return_tab'] ?? '' );
			if ( $tab ) {
				$location = add_query_arg( 'tab', $tab, admin_url( 'admin.php?page=seamless-react' ) );
			}
		}
		return $location;
	}

	// ─── Page render ──────────────────────────────────────────────────────────

	public function render_page(): void {
		$active_tab      = sanitize_text_field( $_GET['tab'] ?? 'authentication' );
		$is_authenticated = $this->auth->is_authenticated();
		?>
		<div class="wrap seamless-react-admin-wrap">
			<h1><?php esc_html_e( 'Seamless React Settings', 'seamless-react' ); ?></h1>

			<nav class="nav-tab-wrapper seamless-react-tabs">
				<?php $this->tab_link( 'authentication', __( 'Authentication', 'seamless-react' ), 'dashicons-admin-network', $active_tab ); ?>
				<?php $this->tab_link( 'endpoints',      __( 'Endpoints', 'seamless-react' ),      'dashicons-admin-links', $active_tab ); ?>
				<?php $this->tab_link( 'events',         __( 'Events', 'seamless-react' ),          'dashicons-calendar', $active_tab ); ?>
				<?php $this->tab_link( 'membership',     __( 'Membership', 'seamless-react' ),      'dashicons-groups', $active_tab ); ?>
				<?php if ( $is_authenticated ) : ?>
					<?php $this->tab_link( 'sso',         __( 'SSO Login', 'seamless-react' ),      'dashicons-admin-users', $active_tab ); ?>
					<?php $this->tab_link( 'restriction', __( 'Content Restriction', 'seamless-react' ), 'dashicons-lock', $active_tab ); ?>
				<?php endif; ?>
				<?php $this->tab_link( 'advanced', __( 'Advanced', 'seamless-react' ), 'dashicons-admin-generic', $active_tab ); ?>
				<?php do_action( 'seamless_react_settings_tabs', $active_tab ); ?>
			</nav>

			<div class="seamless-react-tab-content">
				<div class="seamless-react-card">
					<?php $this->render_tab( $active_tab, $is_authenticated ); ?>
				</div>
			</div>
		</div>
		<?php
		$this->admin_inline_js();
	}

	private function tab_link( string $slug, string $label, string $icon, string $active ): void {
		$url = add_query_arg( [ 'page' => 'seamless-react', 'tab' => $slug ], admin_url( 'admin.php' ) );
		$class = 'nav-tab' . ( $active === $slug ? ' nav-tab-active' : '' );
		printf(
			'<a href="%s" class="%s" data-tab="%s"><span class="dashicons %s"></span> %s</a>',
			esc_url( $url ),
			esc_attr( $class ),
			esc_attr( $slug ),
			esc_attr( $icon ),
			esc_html( $label )
		);
	}

	private function render_tab( string $tab, bool $is_authenticated ): void {
		match ( $tab ) {
			'authentication' => $this->tab_auth(),
			'endpoints'      => $this->tab_endpoints(),
			'events'         => $this->tab_events(),
			'membership'     => $this->tab_membership(),
			'sso'            => $is_authenticated ? $this->tab_sso() : null,
			'restriction'    => $is_authenticated ? $this->tab_restriction() : null,
			'advanced'       => $this->tab_advanced(),
			default          => do_action( 'seamless_react_settings_tab_content_' . $tab ),
		};
	}

	// ─── Tab: Authentication ──────────────────────────────────────────────────

	private function tab_auth(): void {
		$is_auth      = $this->auth->is_authenticated();
		$client_domain = esc_attr( (string) get_option( 'seamless_react_client_domain', '' ) );
		?>
		<div class="seamless-react-auth-tab">
			<?php if ( $is_auth ) : ?>
				<div class="seamless-react-connected-state">
					<span class="dashicons dashicons-yes-alt" style="color:#46b450;font-size:2rem"></span>
					<h3><?php esc_html_e( 'Connected!', 'seamless-react' ); ?></h3>
					<p><?php printf( esc_html__( 'Connected to %s', 'seamless-react' ), '<strong>' . esc_html( get_option( 'seamless_react_client_domain' ) ) . '</strong>' ); ?></p>
					<button type="button" id="sr-disconnect-btn" class="button button-secondary">
						<?php esc_html_e( 'Disconnect', 'seamless-react' ); ?>
					</button>
				</div>
			<?php else : ?>
				<div class="seamless-react-not-connected">
					<h3><?php esc_html_e( 'Connect to your AMS Domain', 'seamless-react' ); ?></h3>
					<p><?php esc_html_e( 'Enter the base URL of your Seamless AMS instance to connect.', 'seamless-react' ); ?></p>
					<table class="form-table">
						<tr>
							<th><label for="sr-client-domain"><?php esc_html_e( 'Client Domain', 'seamless-react' ); ?></label></th>
							<td>
								<input type="url" id="sr-client-domain" name="client_domain"
									value="<?php echo $client_domain; ?>"
									class="regular-text" placeholder="https://yourdomain.com" required />
								<p class="description"><?php esc_html_e( 'The base domain of your Seamless AMS API.', 'seamless-react' ); ?></p>
							</td>
						</tr>
					</table>
					<p>
						<button type="button" id="sr-save-connect-btn" class="button button-primary">
							<span class="dashicons dashicons-admin-network"></span>
							<?php esc_html_e( 'Save and Connect', 'seamless-react' ); ?>
						</button>
					</p>
					<p id="sr-connect-message" style="display:none"></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ─── Tab: Endpoints ───────────────────────────────────────────────────────

	private function tab_endpoints(): void {
		?>
		<form method="post" action="options.php">
			<input type="hidden" name="_seamless_react_return_tab" value="endpoints">
			<?php settings_fields( 'seamless_react_endpoints' ); ?>
			<table class="form-table">
				<?php
				$opts = [
					[ 'seamless_react_event_list_endpoint',   __( 'Event List Endpoint', 'seamless-react' ),   'events' ],
					[ 'seamless_react_single_event_endpoint', __( 'Single Event Endpoint', 'seamless-react' ), 'event' ],
					[ 'seamless_react_ams_content_endpoint',  __( 'AMS Content Endpoint', 'seamless-react' ),  'ams-content' ],
				];
				foreach ( $opts as [ $key, $label, $default ] ) : ?>
					<tr>
						<th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<code><?php echo esc_url( home_url( '/' ) ); ?></code>
							<input type="text" id="<?php echo esc_attr( $key ); ?>"
								name="<?php echo esc_attr( $key ); ?>"
								value="<?php echo esc_attr( get_option( $key, $default ) ); ?>"
								class="regular-text" />
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button( __( 'Save Endpoints', 'seamless-react' ) ); ?>
		</form>
		<?php
	}

	// ─── Tab: Events (shortcode reference) ───────────────────────────────────

	private function tab_events(): void {
		$shortcodes = [
			'[seamless_react_event_list]'                                           => __( 'Events with filter', 'seamless-react' ),
			'[seamless_react_events view="list"]'                                   => __( 'Event list view', 'seamless-react' ),
			'[seamless_react_events view="grid"]'                                   => __( 'Event grid view', 'seamless-react' ),
			'[seamless_react_single_event slug="my-event-slug"]'                    => __( 'Single event', 'seamless-react' ),
			'[seamless_react_memberships]'                                           => __( 'Memberships', 'seamless-react' ),
			'[seamless_react_courses]'                                               => __( 'Courses', 'seamless-react' ),
			'[seamless_react_dashboard]'                                             => __( 'User dashboard', 'seamless-react' ),
		];
		echo '<div class="seamless-react-shortcodes"><ul>';
		foreach ( $shortcodes as $sc => $label ) {
			printf(
				'<li><strong>%s:</strong> <code class="sr-sc">%s</code> <button type="button" class="sr-copy" data-sc="%s"><span class="dashicons dashicons-admin-page"></span></button></li>',
				esc_html( $label ),
				esc_html( $sc ),
				esc_attr( $sc )
			);
		}
		echo '</ul></div>';
	}

	// ─── Tab: Membership (shortcode reference) ────────────────────────────────

	private function tab_membership(): void {
		$this->tab_events(); // reuse shortcode table
	}

	// ─── Tab: SSO ─────────────────────────────────────────────────────────────

	private function tab_sso(): void {
		$client_id    = esc_attr( (string) get_option( 'seamless_react_sso_client_id', '' ) );
		$redirect_uri = rest_url( SSO::REST_NAMESPACE . '/callback' );
		?>
		<form method="post" action="options.php">
			<input type="hidden" name="_seamless_react_return_tab" value="sso">
			<?php settings_fields( 'seamless_react_sso' ); ?>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Client ID', 'seamless-react' ); ?></th>
					<td><input type="text" name="seamless_react_sso_client_id" value="<?php echo $client_id; ?>" class="regular-text" /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'OAuth Redirect URI', 'seamless-react' ); ?></th>
					<td>
						<code class="sr-sc"><?php echo esc_html( $redirect_uri ); ?></code>
						<button type="button" class="sr-copy" data-sc="<?php echo esc_attr( $redirect_uri ); ?>">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
						<p class="description"><?php esc_html_e( 'Add this URI to your Seamless OAuth app settings.', 'seamless-react' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save SSO Credentials', 'seamless-react' ) ); ?>
		</form>
		<?php
	}

	// ─── Tab: Content Restriction ─────────────────────────────────────────────

	private function tab_restriction(): void {
		$protected_types = esc_attr( (string) get_option( 'seamless_react_protected_post_types', '' ) );
		$message         = esc_textarea( (string) get_option( 'seamless_react_restriction_message', '' ) );
		$purchase_url    = esc_attr( (string) get_option( 'seamless_react_membership_purchase_url', '' ) );
		$all_types       = get_post_types( [ 'public' => true ], 'objects' );
		$selected        = array_filter( array_map( 'trim', explode( ',', get_option( 'seamless_react_protected_post_types', '' ) ) ) );
		?>
		<form method="post" action="options.php">
			<input type="hidden" name="_seamless_react_return_tab" value="restriction">
			<?php settings_fields( 'seamless_react_restriction' ); ?>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Protected Post Types', 'seamless-react' ); ?></th>
					<td>
						<?php foreach ( $all_types as $pt ) :
							if ( $pt->name === 'attachment' ) continue; ?>
							<label>
								<input type="checkbox" name="seamless_react_protected_post_types_arr[]"
									value="<?php echo esc_attr( $pt->name ); ?>"
									<?php checked( in_array( $pt->name, $selected, true ) ); ?> />
								<?php echo esc_html( $pt->labels->singular_name ); ?>
							</label><br>
						<?php endforeach; ?>
						<input type="hidden" name="seamless_react_protected_post_types" id="sr-protected-types" value="<?php echo $protected_types; ?>">
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Restriction Message', 'seamless-react' ); ?></th>
					<td><textarea name="seamless_react_restriction_message" rows="5" cols="50" class="large-text"><?php echo $message; ?></textarea></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Membership Purchase URL', 'seamless-react' ); ?></th>
					<td><input type="url" name="seamless_react_membership_purchase_url" value="<?php echo $purchase_url; ?>" class="regular-text" /></td>
				</tr>
			</table>
			<?php submit_button( __( 'Save Restrictions', 'seamless-react' ) ); ?>
		</form>
		<script>
		jQuery(function($){
			$('input[name="seamless_react_protected_post_types_arr[]"]').on('change', function(){
				var selected = $('input[name="seamless_react_protected_post_types_arr[]"]:checked').map(function(){ return this.value; }).get();
				$('#sr-protected-types').val(selected.join(','));
			});
		});
		</script>
		<?php
	}

	// ─── Tab: Advanced ────────────────────────────────────────────────────────

	private function tab_advanced(): void {
		$scheme    = get_option( 'seamless_react_color_scheme',    'theme' );
		$primary   = get_option( 'seamless_react_primary_color',   '#26337a' );
		$secondary = get_option( 'seamless_react_secondary_color', '#06b6d4' );
		$layout    = get_option( 'seamless_react_list_view_layout', 'option_1' );
		?>
		<form method="post" action="options.php">
			<input type="hidden" name="_seamless_react_return_tab" value="advanced">
			<?php settings_fields( 'seamless_react_advanced' ); ?>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Color Scheme', 'seamless-react' ); ?></th>
					<td>
						<label><input type="radio" name="seamless_react_color_scheme" value="theme" <?php checked( $scheme, 'theme' ); ?>> <?php esc_html_e( 'Inherit from active theme', 'seamless-react' ); ?></label><br>
						<label><input type="radio" name="seamless_react_color_scheme" value="plugin" <?php checked( $scheme, 'plugin' ); ?>> <?php esc_html_e( 'Use plugin colors', 'seamless-react' ); ?></label>
					</td>
				</tr>
				<tr class="sr-plugin-colors" style="<?php echo $scheme !== 'plugin' ? 'display:none' : ''; ?>">
					<th><?php esc_html_e( 'Primary Color', 'seamless-react' ); ?></th>
					<td><input type="text" name="seamless_react_primary_color" value="<?php echo esc_attr( $primary ); ?>" class="sr-color-picker" /></td>
				</tr>
				<tr class="sr-plugin-colors" style="<?php echo $scheme !== 'plugin' ? 'display:none' : ''; ?>">
					<th><?php esc_html_e( 'Secondary Color', 'seamless-react' ); ?></th>
					<td><input type="text" name="seamless_react_secondary_color" value="<?php echo esc_attr( $secondary ); ?>" class="sr-color-picker" /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'List View Layout', 'seamless-react' ); ?></th>
					<td>
						<label><input type="radio" name="seamless_react_list_view_layout" value="option_1" <?php checked( $layout, 'option_1' ); ?>> <?php esc_html_e( 'Classic', 'seamless-react' ); ?></label><br>
						<label><input type="radio" name="seamless_react_list_view_layout" value="option_2" <?php checked( $layout, 'option_2' ); ?>> <?php esc_html_e( 'Modern Card', 'seamless-react' ); ?></label>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save Advanced Settings', 'seamless-react' ) ); ?>
		</form>
		<?php
	}

	// ─── Inline admin JS ──────────────────────────────────────────────────────

	private function admin_inline_js(): void {
		?>
		<script>
		jQuery(function($){
			// Color scheme toggle
			$('input[name="seamless_react_color_scheme"]').on('change', function(){
				$('.sr-plugin-colors').toggle($(this).val() === 'plugin');
			}).trigger('change');

			// Color picker
			if($.fn.wpColorPicker){
				$('.sr-color-picker').wpColorPicker();
			}

			// Copy shortcodes
			$(document).on('click', '.sr-copy', function(){
				var sc = $(this).data('sc');
				navigator.clipboard && navigator.clipboard.writeText(sc);
				var $b = $(this).find('.dashicons');
				$b.removeClass('dashicons-admin-page').addClass('dashicons-yes');
				setTimeout(function(){ $b.removeClass('dashicons-yes').addClass('dashicons-admin-page'); }, 1500);
			});

			// Save & Connect
			$('#sr-save-connect-btn').on('click', function(){
				var domain = $('#sr-client-domain').val();
				if(!domain){ alert('Please enter a domain.'); return; }
				$(this).prop('disabled', true).text('Connecting…');
				$.post(seamlessReactAdmin.ajaxUrl, {
					action: 'seamless_react_save_and_connect',
					nonce:  seamlessReactAdmin.saveConnectNonce,
					client_domain: domain
				}, function(res){
					if(res.success){
						$('#sr-connect-message').text(res.data.message).css('color','green').show();
						setTimeout(function(){ location.reload(); }, 1000);
					} else {
						$('#sr-connect-message').text(res.data).css('color','red').show();
					}
					$('#sr-save-connect-btn').prop('disabled', false).text('Save and Connect');
				});
			});

			// Disconnect
			$('#sr-disconnect-btn').on('click', function(){
				if(!confirm('Disconnect from Seamless?')) return;
				$.post(seamlessReactAdmin.ajaxUrl, {
					action: 'seamless_react_disconnect',
					nonce:  seamlessReactAdmin.disconnectNonce,
				}, function(){ location.reload(); });
			});

			// Tab switching
			$('.seamless-react-tabs .nav-tab').on('click', function(e){
				e.preventDefault();
				var tab = $(this).data('tab');
				window.location.href = $(this).attr('href');
			});
		});
		</script>
		<?php
	}
}
